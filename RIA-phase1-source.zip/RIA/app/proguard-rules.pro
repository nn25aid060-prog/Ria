# Phase 1: no shrinking rules needed yet.
