package com.ria.assistant.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDateTime

class LocalCommandRouterTest {
    private fun router(battery: Int? = 80, charging: Boolean = false, online: Boolean = true) =
        LocalCommandRouter(object : DeviceFacts {
            override fun batteryPercent() = battery
            override fun isCharging() = charging
            override fun isOnline() = online
            override fun now(): LocalDateTime = LocalDateTime.of(2026, 11, 21, 15, 5)
        })

    @Test fun battery() = assertEquals("Battery is at 80 percent.", router().route("What's my battery?"))
    @Test fun batteryCharging() =
        assertEquals("Battery is at 80 percent, and charging.", router(charging = true).route("battery level"))
    @Test fun batteryUnknown() = assertTrue(router(battery = null).route("battery").contains("can't read"))
    @Test fun time() = assertEquals("It's 3:05 PM.", router().route("what time is it"))
    @Test fun sometimeIsNotTime() = assertTrue(router().route("sometimes I wonder").startsWith("I heard"))
    @Test fun date() = assertEquals("Today is Saturday, 21 November 2026.", router().route("what's the date"))
    @Test fun offline() = assertEquals("You're offline right now.", router(online = false).route("am I online"))
    @Test fun unknownIsHonest() = assertTrue(router().route("write me a poem").contains("isn't connected yet"))
}
