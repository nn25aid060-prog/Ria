package com.ria.assistant.ui.home

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.ria.assistant.ui.theme.RiaColors
import com.ria.assistant.voice.VoiceState
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Phase 1 holographic avatar drawn with Compose Canvas (stylised female face, rings, circular waveform).
 * The mouth movement while speaking is a generic animation, NOT phoneme lip-sync; the real 3D
 * character with viseme lip-sync is Phase 6.
 */
@Composable
fun RiaAvatar(state: VoiceState, level: Float, modifier: Modifier = Modifier) {
    val color by animateColorAsState(
        targetValue = when (state) {
            VoiceState.IDLE -> RiaColors.Cyan
            VoiceState.LISTENING -> RiaColors.Blue
            VoiceState.THINKING -> RiaColors.Violet
            VoiceState.SPEAKING -> RiaColors.Cyan
            VoiceState.EXECUTING -> RiaColors.Amber
        },
        animationSpec = tween(400), label = "stateColor"
    )

    val t = rememberInfiniteTransition(label = "avatar")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(22000, easing = LinearEasing)), label = "spin")
    val fastSpin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "fastSpin")
    val breathe by t.animateFloat(
        0.975f, 1.025f,
        infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breathe"
    )
    val phase by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "phase")
    val talk by t.animateFloat(0f, 1f, infiniteRepeatable(tween(230), RepeatMode.Reverse), label = "talk")

    val eyeOpen = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(Random.nextLong(2500, 5500))
            eyeOpen.animateTo(0f, tween(70))
            eyeOpen.animateTo(1f, tween(110))
        }
    }

    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        val hair = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
        val thin = Stroke(width = 2.dp.toPx())

        // ambient glow
        drawCircle(
            brush = Brush.radialGradient(listOf(color.copy(alpha = 0.30f), Color.Transparent), center = c, radius = r),
            radius = r, center = c
        )

        // rotating rings
        rotate(spin, pivot = c) {
            drawCircle(
                color.copy(alpha = 0.55f), radius = r * 0.97f, center = c,
                style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 16f)))
            )
        }
        val sweepSpeed = if (state == VoiceState.THINKING || state == VoiceState.EXECUTING) fastSpin else -spin * 2f
        rotate(sweepSpeed, pivot = c) {
            drawArc(
                color.copy(alpha = 0.9f), startAngle = 0f, sweepAngle = 70f, useCenter = false,
                topLeft = Offset(c.x - r * 0.62f, c.y - r * 0.62f), size = Size(r * 1.24f, r * 1.24f),
                style = Stroke(3.dp.toPx(), cap = StrokeCap.Round)
            )
        }

        // circular waveform
        val bars = 72
        val inner = r * 0.72f
        for (i in 0 until bars) {
            val a = (i * 2 * PI / bars).toFloat()
            val wobble = (sin(i * 0.6f + phase) + 1f) / 2f
            val amp = when (state) {
                VoiceState.LISTENING -> 0.1f + level * (0.4f + 0.6f * wobble)
                VoiceState.SPEAKING -> 0.25f + 0.6f * wobble
                VoiceState.THINKING, VoiceState.EXECUTING -> 0.1f + 0.25f * wobble
                VoiceState.IDLE -> 0.04f + 0.06f * wobble
            }
            val len = r * 0.26f * amp
            val dir = Offset(cos(a), sin(a))
            drawLine(
                color.copy(alpha = 0.85f), start = c + dir * inner, end = c + dir * (inner + len),
                strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round
            )
        }

        // stylised face (scaled by breathing)
        val s = r * 1.0f * breathe
        drawArc( // hair
            color.copy(alpha = 0.45f), startAngle = 165f, sweepAngle = 210f, useCenter = false,
            topLeft = Offset(c.x - s * 0.33f, c.y - s * 0.50f), size = Size(s * 0.66f, s * 0.92f), style = hair
        )
        drawOval( // head
            color.copy(alpha = 0.85f), topLeft = Offset(c.x - s * 0.26f, c.y - s * 0.42f),
            size = Size(s * 0.52f, s * 0.74f), style = thin
        )
        drawArc( // shoulders
            color.copy(alpha = 0.5f), startAngle = 200f, sweepAngle = 140f, useCenter = false,
            topLeft = Offset(c.x - s * 0.42f, c.y + s * 0.30f), size = Size(s * 0.84f, s * 0.5f), style = thin
        )
        val open = eyeOpen.value.coerceAtLeast(0.08f)
        for (sign in listOf(-1f, 1f)) {
            val ex = c.x + sign * s * 0.115f
            val ey = c.y - s * 0.10f
            drawOval(color, topLeft = Offset(ex - s * 0.055f, ey - s * 0.022f * open), size = Size(s * 0.11f, s * 0.044f * open))
            drawCircle(Color.White.copy(alpha = 0.9f), radius = s * 0.012f * open, center = Offset(ex, ey))
        }
        drawLine( // nose
            color.copy(alpha = 0.4f), Offset(c.x, c.y - s * 0.04f), Offset(c.x - s * 0.012f, c.y + s * 0.06f),
            strokeWidth = 1.5.dp.toPx(), cap = StrokeCap.Round
        )
        val mouthOpen = when (state) {
            VoiceState.SPEAKING -> 0.2f + 0.8f * abs(talk)
            VoiceState.LISTENING -> 0.1f + 0.5f * level
            else -> 0f
        }
        val mh = s * 0.008f + s * 0.06f * mouthOpen
        drawOval(
            color.copy(alpha = 0.85f), topLeft = Offset(c.x - s * 0.07f, c.y + s * 0.16f - mh / 2f),
            size = Size(s * 0.14f, mh)
        )
    }
}
