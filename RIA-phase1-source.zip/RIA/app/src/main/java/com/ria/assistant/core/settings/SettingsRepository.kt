package com.ria.assistant.core.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

private val Context.riaDataStore: DataStore<Preferences> by preferencesDataStore(name = "ria_settings")

data class RiaSettings(
    /** BCP-47 tag used for speech recognition. */
    val languageTag: String = "en-IN",
    val speakResponses: Boolean = true,
    val speechRate: Float = 1.0f,
    val pitch: Float = 1.1f
)

data class LanguageOption(val tag: String, val label: String)

val SupportedLanguages = listOf(
    LanguageOption("en-IN", "English (India)"),
    LanguageOption("en-US", "English (US)"),
    LanguageOption("kn-IN", "Kannada (ಕನ್ನಡ)"),
    LanguageOption("hi-IN", "Hindi (हिन्दी)")
)

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val LANGUAGE = stringPreferencesKey("language_tag")
        val SPEAK = booleanPreferencesKey("speak_responses")
        val RATE = floatPreferencesKey("speech_rate")
        val PITCH = floatPreferencesKey("pitch")
    }

    val settings: Flow<RiaSettings> = context.riaDataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            val d = RiaSettings()
            RiaSettings(
                languageTag = p[Keys.LANGUAGE] ?: d.languageTag,
                speakResponses = p[Keys.SPEAK] ?: d.speakResponses,
                speechRate = p[Keys.RATE] ?: d.speechRate,
                pitch = p[Keys.PITCH] ?: d.pitch
            )
        }

    suspend fun setLanguage(tag: String) = context.riaDataStore.edit { it[Keys.LANGUAGE] = tag }
    suspend fun setSpeakResponses(v: Boolean) = context.riaDataStore.edit { it[Keys.SPEAK] = v }
    suspend fun setSpeechRate(v: Float) = context.riaDataStore.edit { it[Keys.RATE] = v }
    suspend fun setPitch(v: Float) = context.riaDataStore.edit { it[Keys.PITCH] = v }
}
