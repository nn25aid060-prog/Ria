package com.ria.assistant.ui.home

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ria.assistant.core.status.Transport
import com.ria.assistant.ui.theme.RiaColors
import com.ria.assistant.voice.VoiceState

private val QuickSkills = listOf("Battery" to "battery", "Time" to "what time is it", "Date" to "what is the date", "Network" to "am I online")

@Composable
fun HomeScreen(onOpenSettings: () -> Unit, vm: HomeViewModel = hiltViewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var micDenied by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        micDenied = !granted
        if (granted) vm.toggleListening()
    }

    fun onMicClick() {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) {
            micDenied = false
            vm.toggleListening()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(RiaColors.Black, RiaColors.Navy, RiaColors.Black))
        )
    ) {
        HudGrid(Modifier.fillMaxSize())
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // ---- status row ----
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                val net = ui.network
                val netText = if (net.online) {
                    "ONLINE · " + when (net.transport) {
                        Transport.WIFI -> "WIFI"; Transport.CELLULAR -> "CELL"; Transport.ETHERNET -> "ETH"; else -> "NET"
                    }
                } else "OFFLINE"
                StatusPill(netText, if (net.online) RiaColors.Cyan else RiaColors.Amber)
                Spacer(Modifier.width(8.dp))
                val b = ui.battery
                StatusPill(
                    if (b == null) "BAT —" else "BAT ${b.percent}%" + if (b.charging) " ⚡" else "",
                    if (b != null && b.percent <= 15 && !b.charging) RiaColors.Danger else RiaColors.Blue
                )
                if (ui.voice == VoiceState.LISTENING) {
                    Spacer(Modifier.width(8.dp))
                    StatusPill("● MIC LIVE", RiaColors.Danger)
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = RiaColors.Cyan)
                }
            }

            // ---- avatar ----
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                val side = if (maxWidth < maxHeight) maxWidth else maxHeight
                RiaAvatar(ui.voice, ui.level, Modifier.size(side))
            }

            // ---- state label + live transcript ----
            Text(
                stateLabel(ui.voice),
                color = RiaColors.Cyan, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                fontSize = 14.sp, letterSpacing = 4.sp
            )
            Text(
                text = when {
                    ui.partial.isNotEmpty() -> ui.partial
                    ui.voice == VoiceState.IDLE -> "Tap the mic and speak"
                    else -> ""
                },
                color = RiaColors.TextDim, fontSize = 14.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp).height(22.dp)
            )

            // ---- conversation panel ----
            if (ui.log.isNotEmpty()) {
                Column(
                    Modifier.fillMaxWidth().padding(top = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(RiaColors.Navy.copy(alpha = 0.7f))
                        .border(BorderStroke(1.dp, RiaColors.Cyan.copy(alpha = 0.35f)), RoundedCornerShape(14.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    ui.log.takeLast(4).forEach { line ->
                        Text(
                            (if (line.fromUser) "YOU  ›  " else "RIA  ›  ") + line.text,
                            color = if (line.fromUser) RiaColors.TextDim else Color(0xFFE6F6FF),
                            fontSize = 13.sp
                        )
                    }
                }
            }

            // ---- errors / permission ----
            val message = when {
                micDenied -> "Microphone permission is needed for voice input."
                else -> ui.error
            }
            if (message != null) {
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(message, color = RiaColors.Amber, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    if (micDenied) {
                        TextButton(onClick = {
                            context.startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }) { Text("Open settings") }
                    } else {
                        TextButton(onClick = vm::dismissError) { Text("Dismiss") }
                    }
                }
            }

            // ---- quick skills ----
            LazyRow(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(QuickSkills) { (label, command) ->
                    AssistChip(
                        onClick = { vm.runQuickCommand(command) },
                        label = { Text(label, color = RiaColors.Cyan) },
                        border = AssistChipDefaults.assistChipBorder(enabled = true, borderColor = RiaColors.Cyan.copy(alpha = 0.5f))
                    )
                }
            }

            // ---- mic button ----
            MicButton(listening = ui.voice == VoiceState.LISTENING, onClick = ::onMicClick, modifier = Modifier.padding(top = 12.dp, bottom = 8.dp))
        }
    }
}

private fun stateLabel(s: VoiceState) = when (s) {
    VoiceState.IDLE -> "STANDBY"
    VoiceState.LISTENING -> "LISTENING"
    VoiceState.THINKING -> "PROCESSING"
    VoiceState.SPEAKING -> "SPEAKING"
    VoiceState.EXECUTING -> "EXECUTING"
}

@Composable
private fun StatusPill(text: String, color: Color) {
    Text(
        text, color = color, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 1.sp,
        modifier = Modifier
            .border(BorderStroke(1.dp, color.copy(alpha = 0.6f)), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
private fun MicButton(listening: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val pulse by rememberInfiniteTransition(label = "mic").animateFloat(
        1f, 1.18f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "pulse"
    )
    val tint = if (listening) RiaColors.Danger else RiaColors.Cyan
    Box(modifier.size(96.dp), contentAlignment = Alignment.Center) {
        if (listening) {
            Box(Modifier.size(80.dp * pulse).border(2.dp, tint.copy(alpha = 0.4f), CircleShape))
        }
        Box(
            Modifier.size(72.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(tint.copy(alpha = 0.35f), RiaColors.Navy)))
                .border(2.dp, tint, CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            MicGlyph(tint, listening, Modifier.size(30.dp))
        }
    }
}

/** Mic glyph (or stop square while listening) drawn directly to avoid the large icon library. */
@Composable
private fun MicGlyph(color: Color, stop: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        if (stop) {
            drawRect(color, topLeft = Offset(w * 0.2f, h * 0.2f), size = Size(w * 0.6f, h * 0.6f))
        } else {
            drawRoundRect(
                color, topLeft = Offset(w * 0.36f, 0f), size = Size(w * 0.28f, h * 0.55f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.14f)
            )
            drawArc(
                color, startAngle = 0f, sweepAngle = 180f, useCenter = false,
                topLeft = Offset(w * 0.2f, h * 0.18f), size = Size(w * 0.6f, h * 0.55f),
                style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round)
            )
            drawLine(color, Offset(w * 0.5f, h * 0.73f), Offset(w * 0.5f, h * 0.95f), strokeWidth = 2.5.dp.toPx(), cap = StrokeCap.Round)
        }
    }
}

@Composable
private fun HudGrid(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val step = 48.dp.toPx()
        val c = RiaColors.Cyan.copy(alpha = 0.05f)
        var x = 0f
        while (x < size.width) { drawLine(c, Offset(x, 0f), Offset(x, size.height)); x += step }
        var y = 0f
        while (y < size.height) { drawLine(c, Offset(0f, y), Offset(size.width, y)); y += step }
    }
}
