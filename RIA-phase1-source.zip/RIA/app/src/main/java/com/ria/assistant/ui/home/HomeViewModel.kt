package com.ria.assistant.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ria.assistant.ai.DeviceFacts
import com.ria.assistant.ai.LocalCommandRouter
import com.ria.assistant.core.settings.RiaSettings
import com.ria.assistant.core.settings.SettingsRepository
import com.ria.assistant.core.status.BatteryInfo
import com.ria.assistant.core.status.DeviceStatusMonitor
import com.ria.assistant.core.status.NetworkState
import com.ria.assistant.voice.VoiceController
import com.ria.assistant.voice.VoiceState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import javax.inject.Inject

data class ChatLine(val fromUser: Boolean, val text: String)

data class HomeUiState(
    val voice: VoiceState = VoiceState.IDLE,
    val level: Float = 0f,
    val partial: String = "",
    val battery: BatteryInfo? = null,
    val network: NetworkState = NetworkState.OFFLINE,
    val log: List<ChatLine> = emptyList(),
    val error: String? = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val voice: VoiceController,
    status: DeviceStatusMonitor,
    settingsRepo: SettingsRepository
) : ViewModel() {

    private val settings: StateFlow<RiaSettings> =
        settingsRepo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, RiaSettings())

    private val _ui = MutableStateFlow(HomeUiState())
    val ui: StateFlow<HomeUiState> = _ui.asStateFlow()

    private val router = LocalCommandRouter(object : DeviceFacts {
        override fun batteryPercent() = _ui.value.battery?.percent
        override fun isCharging() = _ui.value.battery?.charging == true
        override fun isOnline() = _ui.value.network.online
        override fun now(): LocalDateTime = LocalDateTime.now()
    })

    init {
        viewModelScope.launch { voice.state.collect { s -> _ui.update { it.copy(voice = s) } } }
        viewModelScope.launch { voice.level.collect { l -> _ui.update { it.copy(level = l) } } }
        viewModelScope.launch { voice.partial.collect { p -> _ui.update { it.copy(partial = p) } } }
        viewModelScope.launch { voice.error.collect { e -> _ui.update { it.copy(error = e) } } }
        viewModelScope.launch { status.battery.collect { b -> _ui.update { it.copy(battery = b) } } }
        viewModelScope.launch { status.network.collect { n -> _ui.update { it.copy(network = n) } } }
        viewModelScope.launch { voice.utterances.collect { handleUtterance(it) } }
    }

    /** Mic button: start listening (interrupting speech) or stop capturing. */
    fun toggleListening() {
        if (_ui.value.voice == VoiceState.LISTENING) voice.stopListening()
        else voice.startListening(settings.value.languageTag)
    }

    /** Quick-access skill chips run the same path as a spoken command. */
    fun runQuickCommand(text: String) = handleUtterance(text)

    fun dismissError() = voice.clearError()

    private fun handleUtterance(text: String) {
        voice.setThinking()
        val reply = router.route(text)
        _ui.update { it.copy(log = (it.log + ChatLine(true, text) + ChatLine(false, reply)).takeLast(6)) }
        val s = settings.value
        if (s.speakResponses) {
            // Phase 1 replies are English, so speak with an English voice.
            val tag = if (s.languageTag.startsWith("en")) s.languageTag else "en-IN"
            voice.speak(reply, tag, s.speechRate, s.pitch)
        } else {
            voice.setIdle()
        }
    }
}
