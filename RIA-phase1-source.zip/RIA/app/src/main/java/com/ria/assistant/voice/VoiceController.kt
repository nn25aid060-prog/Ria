package com.ria.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Push-to-talk voice pipeline built on Android's SpeechRecognizer + TextToSpeech.
 * Must be driven from the main thread (ViewModels do this).
 */
@Singleton
class VoiceController @Inject constructor(
    @ApplicationContext private val context: Context,
    private val tts: TextToSpeechManager
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _state = MutableStateFlow(VoiceState.IDLE)
    val state: StateFlow<VoiceState> = _state.asStateFlow()

    /** Normalised microphone level 0..1 while listening. */
    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()

    private val _partial = MutableStateFlow("")
    val partial: StateFlow<String> = _partial.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _utterances = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val utterances: SharedFlow<String> = _utterances.asSharedFlow()

    private var recognizer: SpeechRecognizer? = null

    init {
        scope.launch {
            tts.speaking.collect { speaking ->
                if (speaking) _state.value = VoiceState.SPEAKING
                else if (_state.value == VoiceState.SPEAKING) _state.value = VoiceState.IDLE
            }
        }
    }

    fun startListening(languageTag: String) {
        if (_state.value == VoiceState.LISTENING) return
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _error.value = "Speech recognition is not available on this device."
            return
        }
        tts.stop() // interrupt RIA if she is talking
        _error.value = null
        _partial.value = ""
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        r.setRecognitionListener(listener)
        recognizer = r
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        _state.value = VoiceState.LISTENING
        r.startListening(intent)
    }

    /** Ends capture; the recognizer will still deliver a final result. */
    fun stopListening() {
        recognizer?.stopListening()
    }

    fun setThinking() { _state.value = VoiceState.THINKING }
    fun setIdle() { _state.value = VoiceState.IDLE }
    fun clearError() { _error.value = null }

    fun speak(text: String, languageTag: String, rate: Float, pitch: Float) {
        when (tts.speak(text, languageTag, rate, pitch)) {
            SpeakResult.OK -> Unit
            SpeakResult.LANGUAGE_FALLBACK -> _error.value =
                "Voice data for $languageTag isn't installed; using the default voice."
            SpeakResult.NOT_READY -> { _error.value = "The voice engine is still starting."; setIdle() }
            SpeakResult.FAILED -> { _error.value = "Text-to-speech failed."; setIdle() }
        }
    }

    fun release() {
        recognizer?.destroy()
        recognizer = null
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onRmsChanged(rmsdB: Float) {
            _level.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()?.let { _partial.value = it }
        }

        override fun onResults(results: Bundle?) {
            _level.value = 0f
            _partial.value = ""
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()?.trim()
            if (text.isNullOrEmpty()) {
                _state.value = VoiceState.IDLE
            } else {
                _state.value = VoiceState.THINKING
                _utterances.tryEmit(text)
            }
        }

        override fun onError(error: Int) {
            _level.value = 0f
            _partial.value = ""
            _state.value = VoiceState.IDLE
            _error.value = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't catch that. Try again."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is missing."
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                    "Speech service needs a network connection for this language (offline STT arrives in Phase 2)."
                SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer is busy. Try again."
                12, 13 -> "This language isn't available for speech recognition on this device."
                else -> "Speech recognition error ($error)."
            }
        }
    }
}
