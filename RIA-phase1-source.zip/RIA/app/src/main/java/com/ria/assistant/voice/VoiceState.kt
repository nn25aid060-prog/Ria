package com.ria.assistant.voice

enum class VoiceState { IDLE, LISTENING, THINKING, SPEAKING, EXECUTING }
