package com.ria.assistant.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ria.assistant.core.settings.RiaSettings
import com.ria.assistant.core.settings.SettingsRepository
import com.ria.assistant.voice.SpeakResult
import com.ria.assistant.voice.TextToSpeechManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val repo: SettingsRepository,
    private val tts: TextToSpeechManager
) : ViewModel() {

    val settings: StateFlow<RiaSettings> =
        repo.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RiaSettings())

    fun setLanguage(tag: String) = viewModelScope.launch { repo.setLanguage(tag) }
    fun setSpeak(v: Boolean) = viewModelScope.launch { repo.setSpeakResponses(v) }
    fun setRate(v: Float) = viewModelScope.launch { repo.setSpeechRate(v) }
    fun setPitch(v: Float) = viewModelScope.launch { repo.setPitch(v) }

    /** Plays a sample so the user can hear the current voice settings. Returns the result for UI feedback. */
    fun testVoice(): SpeakResult {
        val s = settings.value
        val tag = if (s.languageTag.startsWith("en")) s.languageTag else "en-IN"
        return tts.speak("Hello, I'm RIA. This is how I sound.", tag, s.speechRate, s.pitch)
    }
}
