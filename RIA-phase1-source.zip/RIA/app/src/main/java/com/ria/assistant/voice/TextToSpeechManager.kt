package com.ria.assistant.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

enum class SpeakResult { OK, LANGUAGE_FALLBACK, NOT_READY, FAILED }

/** Wrapper around Android TextToSpeech using the device's installed TTS engine/voices. */
@Singleton
class TextToSpeechManager @Inject constructor(
    @ApplicationContext context: Context
) {
    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()

    @Volatile private var ready = false
    private var engine: TextToSpeech? = null

    init {
        engine = TextToSpeech(context) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { _speaking.value = true }
                    override fun onDone(utteranceId: String?) { _speaking.value = false }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { _speaking.value = false }
                    override fun onStop(utteranceId: String?, interrupted: Boolean) {
                        _speaking.value = false
                    }
                })
            }
        }
    }

    fun speak(text: String, languageTag: String, rate: Float, pitch: Float): SpeakResult {
        val tts = engine
        if (!ready || tts == null) return SpeakResult.NOT_READY
        var result = SpeakResult.OK
        val langStatus = tts.setLanguage(Locale.forLanguageTag(languageTag))
        if (langStatus == TextToSpeech.LANG_MISSING_DATA || langStatus == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale.getDefault())
            result = SpeakResult.LANGUAGE_FALLBACK
        }
        tts.setSpeechRate(rate)
        tts.setPitch(pitch)
        val code = tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ria-utterance")
        return if (code == TextToSpeech.SUCCESS) result else SpeakResult.FAILED
    }

    /** Stops playback immediately (voice interruption). */
    fun stop() {
        engine?.stop()
        _speaking.value = false
    }
}
