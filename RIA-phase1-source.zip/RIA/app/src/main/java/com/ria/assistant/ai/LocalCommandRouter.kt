package com.ria.assistant.ai

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Read-only device facts the router may report. Implemented from real system state. */
interface DeviceFacts {
    fun batteryPercent(): Int?
    fun isCharging(): Boolean
    fun isOnline(): Boolean
    fun now(): LocalDateTime
}

/**
 * Phase 1 stand-in for the AI brain: answers a few commands from real local data.
 * Anything else is reported honestly as unsupported (the LLM brain lands in Phase 3).
 */
class LocalCommandRouter(private val facts: DeviceFacts) {

    fun route(utterance: String): String {
        val t = utterance.lowercase(Locale.ROOT)
        return when {
            "battery" in t -> {
                val p = facts.batteryPercent()
                if (p == null) "I can't read the battery level right now."
                else "Battery is at $p percent" + if (facts.isCharging()) ", and charging." else "."
            }
            Regex("\\btime\\b").containsMatchIn(t) ->
                "It's " + facts.now().format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH)) + "."
            Regex("\\b(date|today|day)\\b").containsMatchIn(t) ->
                "Today is " + facts.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.ENGLISH)) + "."
            Regex("\\b(network|internet|online|wifi|wi-fi)\\b").containsMatchIn(t) ->
                if (facts.isOnline()) "You're online." else "You're offline right now."
            else -> "I heard: \"$utterance\". My reasoning engine isn't connected yet, " +
                "so for now I can only report battery, time, date and network status."
        }
    }
}
