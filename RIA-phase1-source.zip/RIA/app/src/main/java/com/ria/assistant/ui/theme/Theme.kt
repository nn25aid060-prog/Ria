package com.ria.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object RiaColors {
    val Black = Color(0xFF02040A)
    val Navy = Color(0xFF071229)
    val Cyan = Color(0xFF00E5FF)
    val Blue = Color(0xFF3DA5FF)
    val Violet = Color(0xFF8A7CFF)
    val Amber = Color(0xFFFFB347)
    val Danger = Color(0xFFFF4D6A)
    val TextDim = Color(0xFF8FB4D9)
}

private val scheme = darkColorScheme(
    primary = RiaColors.Cyan,
    secondary = RiaColors.Blue,
    background = RiaColors.Black,
    surface = RiaColors.Navy,
    onPrimary = RiaColors.Black,
    onBackground = Color(0xFFE6F6FF),
    onSurface = Color(0xFFE6F6FF)
)

@Composable
fun RiaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
