package com.ria.assistant.ui.settings

import android.Manifest
import android.content.pm.PackageManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ria.assistant.core.settings.SupportedLanguages
import com.ria.assistant.ui.theme.RiaColors
import com.ria.assistant.voice.SpeakResult

@Composable
fun SettingsScreen(onBack: () -> Unit, vm: SettingsViewModel = hiltViewModel()) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val micGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED
    var testNote by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().background(RiaColors.Black).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = RiaColors.Cyan)
            }
            Text("SETTINGS", color = RiaColors.Cyan, fontSize = 18.sp, letterSpacing = 4.sp)
        }

        Section("Voice input language")
        SupportedLanguages.forEach { lang ->
            Row(
                Modifier.fillMaxWidth().clickable { vm.setLanguage(lang.tag) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = s.languageTag == lang.tag, onClick = { vm.setLanguage(lang.tag) })
                Text(lang.label)
            }
        }
        Text(
            "Recognition uses your device's speech service. Kannada/Hindi availability depends on the device; " +
                "RIA's replies are English until the AI brain is added (Phase 3).",
            color = RiaColors.TextDim, fontSize = 12.sp
        )

        Section("Voice output")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Speak responses", Modifier.weight(1f))
            Switch(checked = s.speakResponses, onCheckedChange = vm::setSpeak)
        }
        Text("Speech rate: ${"%.2f".format(s.speechRate)}", fontSize = 13.sp)
        Slider(value = s.speechRate, onValueChange = vm::setRate, valueRange = 0.5f..1.5f)
        Text("Pitch: ${"%.2f".format(s.pitch)}", fontSize = 13.sp)
        Slider(value = s.pitch, onValueChange = vm::setPitch, valueRange = 0.7f..1.5f)
        Button(onClick = {
            testNote = when (vm.testVoice()) {
                SpeakResult.OK -> null
                SpeakResult.LANGUAGE_FALLBACK -> "That voice isn't installed; using the default."
                SpeakResult.NOT_READY -> "Voice engine is still starting. Try again."
                SpeakResult.FAILED -> "Text-to-speech failed. Check your device's TTS settings."
            }
        }) { Text("Test voice") }
        testNote?.let { Text(it, color = RiaColors.Amber, fontSize = 12.sp) }
        Text(
            "The voice is whichever one your device's text-to-speech engine provides. " +
                "Install a female voice in Android Settings → Text-to-speech output.",
            color = RiaColors.TextDim, fontSize = 12.sp
        )

        Section("Permissions")
        Text(
            "Microphone: " + if (micGranted) "granted" else "not granted (requested when you tap the mic)",
            color = if (micGranted) RiaColors.Cyan else RiaColors.Amber
        )
        Text(
            "RIA only listens while you tap the mic, and shows a MIC LIVE indicator while the microphone is open.",
            color = RiaColors.TextDim, fontSize = 12.sp
        )

        Section("About")
        Text("RIA — Responsive Intelligent Assistant\nVersion 0.1.0 (Phase 1 foundation)", fontSize = 13.sp)
        Text(
            "Not yet implemented: wake word, offline STT, AI brain, memory, skills, 3D avatar, World Monitor, PC link.",
            color = RiaColors.TextDim, fontSize = 12.sp
        )
    }
}

@Composable
private fun Section(title: String) {
    Text(title.uppercase(), color = RiaColors.Blue, fontSize = 12.sp, letterSpacing = 2.sp,
        style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
}
