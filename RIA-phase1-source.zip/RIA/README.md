# RIA — Responsive Intelligent Assistant (Android)

**Status: Phase 1 foundation (v0.1.0).** Not yet compiled or run by the author's tooling — the first
CI build is the first real compile. If it fails, send the build log and it will be fixed.

## Get the APK (no Android Studio needed)
1. Create an empty GitHub repository and push this folder to it (`main` branch):
   ```
   git init && git add . && git commit -m "RIA phase 1"
   git branch -M main
   git remote add origin https://github.com/<you>/ria.git
   git push -u origin main
   ```
2. Open the repo → **Actions** → *Build RIA APK* → latest run → **Artifacts** → download `RIA-debug-apk`.
3. Unzip it to get `app-debug.apk`. On your phone: copy it over, tap it, and allow
   "Install unknown apps" for your file manager/browser. (Debug-signed; fine for personal use.)

## Build locally instead
Open this folder in Android Studio (Koala or newer, JDK 17) and press Run, or:
`./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`.

## What works in Phase 1
- Cinematic home screen: animated holographic avatar (Compose Canvas), circular waveform that reacts to
  mic level, IDLE / LISTENING / THINKING / SPEAKING states, MIC LIVE indicator.
- Real battery and network status (system callbacks).
- Push-to-talk using Android `SpeechRecognizer` (English-India/US, Kannada, Hindi — device dependent),
  runtime mic-permission flow with "Open settings" on denial.
- Spoken replies via Android `TextToSpeech`; tapping the mic interrupts speech.
- Local commands answered from real data: battery, time, date, network. Anything else is reported
  honestly as unsupported — there is no AI brain yet.
- Settings (DataStore): language, speak on/off, speech rate, pitch, voice test.
- Unit tests for the command router.

## Known limits (not faked)
- The avatar is a 2D stylised placeholder; mouth motion while speaking is generic, **not** lip-sync.
  Real 3D character + viseme sync is Phase 6.
- Speech recognition uses the device's Google/OEM service; some languages need network.
- TTS voice is whatever your device provides; install a female voice in Android TTS settings.
- Not implemented yet: wake word ("Hey RIA"), offline STT (Vosk), cloud/local LLM, memory (Room),
  skills, custom skills, World Monitor, Windows companion, backend, signed release APK.

## Roadmap / external dependencies
| Phase | Needs |
|---|---|
| 2 Voice | Vosk model files; Picovoice access key (free tier) for "Hey RIA" |
| 3 AI brain | FastAPI backend holding your cloud-LLM API key; llama.cpp + a GGUF model |
| 4 Memory | Room + encrypted storage (no external service) |
| 6 Character | Blender-made rigged model + Filament |
| 7 Remote | Windows companion (Python/Tauri) + authenticated WebSocket |
| 8 Release | Your own keystore for a signed release APK |
